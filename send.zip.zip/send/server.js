const caseRoutes = require("./routes/cases");
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { Pool } = require("pg");

dotenv.config();

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// PostgreSQL / Neon connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false,
  },
});

// Test database connection
app.get("/api/health", async (req, res) => {
  try {
    const result = await pool.query("SELECT NOW()");

    res.json({
      success: true,
      message: "D-FORCE backend and Neon database are connected!",
      databaseTime: result.rows[0].now,
    });
  } catch (error) {
    console.error("Database connection error:", error);

    res.status(500).json({
      success: false,
      message: "Database connection failed",
    });
  }
});

// Basic home route
app.get("/", (req, res) => {
  res.json({
    message: "D-FORCE Backend API is running",
  });
});

// Case routes
app.use("/api/cases", caseRoutes);

// Start server
app.listen(PORT, () => {
  console.log(`D-FORCE backend running on http://localhost:${PORT}`);
});