const express = require("express");
const router = express.Router();
const db = require("../db");

// Create a new investigation case
router.post("/", async (req, res) => {
  try {
    const { case_number, title, description, priority, status, investigator } = req.body;

    const result = await db.query(
      `INSERT INTO cases
       (case_number, title, description, priority, status, investigator)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        case_number,
	title,
        description,
        priority || "MEDIUM",
        status || "Under Investigation",
        investigator
      ]
    );

    res.status(201).json({
      success: true,
      message: "Case created successfully",
      case: result.rows[0]
    });

  } catch (error) {
    console.error("Create case error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create case",
      error: error.message
    });
  }
});

// Get all cases
router.get("/", async (req, res) => {
  try {
    const result = await db.query(
      "SELECT * FROM cases ORDER BY created_at DESC"
    );

    res.json({
      success: true,
      cases: result.rows
    });

  } catch (error) {
    console.error("Get cases error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch cases",
      error: error.message
    });
  }
});

module.exports = router;