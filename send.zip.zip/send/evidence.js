const express = require("express");
const router = express.Router();
const multer = require("multer");
const crypto = require("crypto");
const fs = require("fs");
const db = require("../db");

const upload = multer({ dest: "uploads/" });

// Upload evidence
router.post("/:caseId", upload.single("file"), async (req, res) => {
  try {
    const caseId = req.params.caseId;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No evidence file uploaded"
      });
    }

    const fileBuffer = fs.readFileSync(req.file.path);

    // Generate SHA-256 hash
    const sha256 = crypto
      .createHash("sha256")
      .update(fileBuffer)
      .digest("hex");

    const evidenceId = "EVD-" + Date.now();

    const result = await db.query(
      `INSERT INTO evidence
       (case_id, evidence_id, file_name, file_type, file_size, sha256_hash)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        caseId,
        evidenceId,
        req.file.originalname,
        req.file.mimetype,
        req.file.size,
        sha256
      ]
    );

    // Create a basic forensic finding automatically
    const findingCode = "FND-" + Date.now();

    const finding = await db.query(
      `INSERT INTO findings
       (case_id, finding_code, title, description, severity, risk_score)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        caseId,
        findingCode,
        "Evidence Requires Investigation",
        "Digital evidence was uploaded and cryptographically verified using SHA-256.",
        "HIGH",
        75
      ]
    );

    // Link finding to evidence
    await db.query(
      `INSERT INTO finding_evidence
       (finding_id, evidence_id, explanation)
       VALUES ($1, $2, $3)`,
      [
        finding.rows[0].id,
        result.rows[0].id,
        "Finding is directly supported by the uploaded and SHA-256 verified evidence."
      ]
    );

    res.status(201).json({
      success: true,
      message: "Evidence uploaded and analyzed successfully",
      evidence: result.rows[0],
      finding: finding.rows[0],
      traceability: {
        evidence_id: result.rows[0].evidence_id,
        finding_code: finding.rows[0].finding_code,
        risk_score: finding.rows[0].risk_score
      }
    });

  } catch (error) {
    console.error("Evidence error:", error);

    res.status(500).json({
      success: false,
      message: "Evidence processing failed",
      error: error.message
    });
  }
});

module.exports = router;